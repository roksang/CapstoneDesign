<?php
$host = 'localhost';
	$user = 'root';
	$pass = '123456';
	$db = 'test';
	$mysqli = new mysqli($host,$user,$pass,$db) or die($mysqli->error);

$Buffer = '';
//$data2 = '';

  //query to get data from the table
  $sql = "SELECT Buffer FROM waterlevel ";
  $result = mysqli_query($mysqli, $sql);

  //loop through the returned data
  while ($row = mysqli_fetch_array($result)) {

    $Buffer = $Buffer . '"'. $row['Buffer'].'",';
  }

  $Buffer = trim($Buffer,",");

?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>심청이 - Dashboard</title>
  <script src="http://code.jquery.com/jquery.min.js"></script>
      <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="http://localhost/php/sim/index.php">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">SIMCHUNG E</div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="http://localhost/php/sim/index.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Service
      </div>



      <!-- Nav Item - Utilities Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="howto.html">
          <i class="fas fa-fw fa-wrench"></i>
          <span>행동요령</span>
        </a>
        <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Custom Utilities:</h6>
            <a class="collapse-item" href="utilities-color.html">Colors</a>
            <a class="collapse-item" href="utilities-border.html">Borders</a>
            <a class="collapse-item" href="utilities-animation.html">Animations</a>
            <a class="collapse-item" href="utilities-other.html">Other</a>
          </div>
        </div>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">



      <!-- Nav Item - Tables -->
      <li class="nav-item">
        <a class="nav-link" href="module.html">
          <i class="fas fa-fw fa-table"></i>
          <span>수위측정기현황</span></a>
      </li>

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->


          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Search -->
          <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search"></form>


        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
          </div>


          <div class="row">
            <div class="col-xl-8 col-lg-7">
              <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">시간별 수위 관측표</h6></div>
                <div class="card-body">
						<div id="chart_div"></div>
					</div>
				</div>
			</div>

            <!-- Area Chart -->
            <div class="col-xl-8 col-lg-7">
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">주간별 수위 관측표</h6>
                  <div class="dropdown no-arrow">
                    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                    </a>
                  </div>
                </div>
			
                <!-- Card Body -->
                <div class="card-body">
                  <html>
                    <head>
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.bundle.min.js"></script>
                      <title>waterlevel</title>

                      <style type="text/css">
                        <body{
                          font-family: Arial;
                            padding: 0;
                            color: white;
                            text-align: center;
                            background: #555652;
                        }

                        .container {
                          color: #E8E9EB;
                          background: #FFFFFF;

                          padding: 3px;
                        }
						</body>
                      </style>

                    </head>

                    <body>
                        <div class="container">
                        <canvas id="chart" style="width: 100%; height: 65vh; background: #FFFFFF; border: 1px  "></canvas>

                        <script>
                          var ctx = document.getElementById("chart").getContext('2d');
                            var myChart = new Chart(ctx, {
                              type: 'line',
                              data: {
                                  labels: ['11주전','10주전','9주전','8주전','7주전','6주전','5주전','4주전','3주전','2주전','1주전','이번주'],
                                  datasets:
                                  [{
                                      label: '현재수위',
                                      data: [<?php echo $Buffer; ?>],
                                      backgroundColor: 'transparent',
                                      borderColor:'rgba(61,110,244)',
                                      borderWidth: 3
                                  }]
                              },

                              options: {
                                  scales: {scales:{yAxes: [{beginAtZero: false}], xAxes: [{autoskip: true, maxTicketsLimit: 20}]}},
                                  tooltips:{mode: 'index'},
                                  legend:{display: true, position: 'top', labels: {fontColor: 'rgb(0,0,0)', fontSize: 16}}
                              }
                          });
                        </script>
                        </div>

                    </body>
                  </html>

                  </div>
                </div>
              </div>
            </div>
		</div>





  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="https://www.google.com/jsapi"></script>
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>


  <script>	window.onload = function () {
            if (window.Notification) {
                Notification.requestPermission();
            }
    }
      var waterlevel = "<?php 
      $sql = "SELECT Buffer FROM waterlevel ORDER BY dates DESC, times DESC LIMIT 1";
      $query = mysqli_query($mysqli, $sql);
      while($row = mysqli_fetch_array($query)){
        echo "".$row['Buffer']."";
        } ?>"; 

        function calculate() {
            setTimeout(function () {
                notify();
            }, 1000);
        }
        
        function notify() {
            if (Notification.permission !== 'granted') {
                alert('notification is disabled');
            }
            else if(waterlevel > 6 && waterlevel <= 15){
                var notification = new Notification('1 level', {
                    icon: 'http://localhost/php/sim/waterdrop.png',
                    body: '1 단계입니다.',
                });
             }
            else if(waterlevel >=0 && waterlevel <= 6){
                var notification = new Notification('0 level',{
                icon : 'http://localhost/php/sim/waterdrop.png',
                body : '0 단계입니다.',
                });
            }
            else if(waterlevel >15 && waterlevel <= 21){
                var notification = new Notification('2 level',{
                icon : 'http://localhost/php/sim/waterdrop.png',
                body : '2 단계입니다.',
                });
            }
 
            notification.onclick = function () {
                window.open('http://localhost/php/sim/howto.html');
            }
        }

        
        if(waterlevel >= 0) calculate();
	</script>

</body>
<script>


	google.charts.load('current', {packages:['corechart']});

    // Set a callback to run when the Google Visualization API is loaded.
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {

      // Create our data table out of JSON data loaded from server.
      var data = new google.visualization.arrayToDataTable([['time','level'],
        <?php
       
		  $sql = "SELECT * FROM waterlevel ";
		  $query = mysqli_query($mysqli, $sql);
		  $a0 = 6;
		  $a1 = 15;
		  $a2 = 18;
		  
        while($row = mysqli_fetch_array($query)){
		echo "['".$row['times']."',".$row['Buffer']."],";   
		//if(Number(.$row['Buffer'].)>$a0)echo "['".$row['times']."',".$row['Buffer']."],"; 
		//else if(Number(.$row['Buffer'].)>$a1)echo "['".$row['times']."',".$row['Buffer']."],"; 
		//else if(Number(.$row['Buffer'].)>$a2)echo "['".$row['times']."',".$row['Buffer']."],"; 
		}
      ?>
      ]);

      var options = {
        title: '실시간 수위 현황',
        annotations: {
          alwaysOutside: true,
          textStyle: {
            fontSize: 14,
            color: '#000',
            auraColor: 'none'
          }
        },
        hAxis: {
          title: 'Time of Day',
          format: 'h시간 전 '
        }
      };

      var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
      chart.draw(data, options);
        
    }
  </script>
</html>
